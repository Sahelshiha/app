package com.andromeda.ara.models

data class HaModel(val link:String, val key:String)