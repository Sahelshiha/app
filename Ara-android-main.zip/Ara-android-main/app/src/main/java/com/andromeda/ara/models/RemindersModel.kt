package com.andromeda.araserver.util

data class RemindersModel(val header:String, val body: String?, val time:Long?) {
}