package com.andromeda.ara.util
data class NewsData(val title:String, val info:String, val smallInfo:String, val link:String, val pic:String)