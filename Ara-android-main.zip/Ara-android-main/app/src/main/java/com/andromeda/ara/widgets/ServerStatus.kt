package com.andromeda.ara.widgets
import android.content.Context
import android.view.View
class ServerStatus(){
	init{


	}

	fun getAllUrls(){

	}
	class ServerView(context:Context): View(context){
		
	}
	data class ServerData(val url:String, val name:String?, val version:String?, val comptability:String?, val status:String)
}
