package com.andromeda.ara.client.models

data class HaModel(val link:String, val key:String)