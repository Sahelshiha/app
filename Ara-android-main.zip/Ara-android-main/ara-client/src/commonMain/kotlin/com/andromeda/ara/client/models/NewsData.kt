package com.andromeda.ara.client.models
data class NewsData(val title:String, val info:String, val smallInfo:String, val link:String, val pic:String)