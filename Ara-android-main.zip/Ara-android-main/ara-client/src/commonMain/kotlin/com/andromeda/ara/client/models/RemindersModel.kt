package com.andromeda.ara.client.models

data class RemindersModel(val header:String, val body: String?, val time:Long?) {
}